{ 
  "prompt1": "Welcome to the calculator!",
  "prompt2": "Whats the first number?",
  "prompt3": "Whats the second number?",
  "prompt4": "What operation would you like to perform?\n1) Add 2) Subtract 3) Multiply 4) Divide"
}
