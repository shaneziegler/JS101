for (let i = 0; i < 10; i += 1) {
  console.log("".padStart(i,) + 'The Flintstones Rock!');
}

// launch solution
for (let padding = 1; padding <= 10; padding++) {
  console.log(" ".repeat(padding) + "The Flinstones Rock!");
}
