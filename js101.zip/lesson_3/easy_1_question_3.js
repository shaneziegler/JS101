let munstersDescription = "the Munsters are CREEPY and Spooky.";
// => The munsters are creepy and spooky.

let newMun = munstersDescription[0].toUpperCase() + munstersDescription.toLowerCase().slice(1);

console.log(newMun);


//munstersDescription.charAt(0).toUpperCase() +
//  munstersDescription.substring(1).toLowerCase();