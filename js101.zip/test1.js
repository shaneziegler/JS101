console.log(greeting);
var greeting = 'Hello world!';
