for (i = 0; i < 10; i++) {
    let x = i % 2;
    console.log(`${i} : ${x}`);
}